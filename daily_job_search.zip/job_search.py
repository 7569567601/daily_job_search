import smtplib
import requests
from bs4 import BeautifulSoup
from email.mime.text import MIMEText
from datetime import datetime
import os

SEARCH_TERMS = [
    "BPO jobs", "BPM jobs", "Content Moderation", "Mapping job",
    "Application Support Engineer", "Graduate Engineer Trainee",
    "Service Desk Analyst", "Data Analyst fresher"
]
COMPANIES = ["Google", "Microsoft", "TCS", "Infosys", "Flipkart", "Swiggy", "Amazon", "Zoho", "Freshworks", "CRED"]

EMAIL_FROM = os.environ['EMAIL_FROM']
EMAIL_TO = os.environ['EMAIL_TO']
EMAIL_PASS = os.environ['EMAIL_PASS']
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

def search_jobs(term):
    url = f"https://www.google.com/search?q={term.replace(' ', '+')}+jobs"
    headers = {"User-Agent": "Mozilla/5.0"}
    resp = requests.get(url, headers=headers)
    soup = BeautifulSoup(resp.text, 'html.parser')
    links = soup.find_all("a", href=True)
    jobs = []
    for link in links:
        href = link['href']
        if "url?q=" in href and any(c.lower() in href.lower() for c in COMPANIES):
            clean_link = href.split("url?q=")[1].split("&")[0]
            jobs.append(clean_link)
    return jobs[:10]

def send_email(subject, body):
    msg = MIMEText(body, "plain")
    msg['Subject'] = subject
    msg['From'] = EMAIL_FROM
    msg['To'] = EMAIL_TO

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(EMAIL_FROM, EMAIL_PASS)
        server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())

def main():
    all_results = []
    for term in SEARCH_TERMS:
        jobs = search_jobs(term)
        all_results.append(f"\n\n🔍 Jobs for '{term}':\n" + "\n".join(jobs))
    final_message = "\n\n".join(all_results)
    send_email(f"🗂 Daily Job Search - {datetime.today().strftime('%Y-%m-%d')}", final_message)

if __name__ == "__main__":
    main()